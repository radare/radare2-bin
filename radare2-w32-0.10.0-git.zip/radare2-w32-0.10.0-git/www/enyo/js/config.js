var Config = {
  "keys": {
    "1": "this.setIndex(0)",
    "2": "this.setIndex(1)",
    "3": "this.setIndex(2)",
    // Most of this keya are used in disassembly so it makes no sense leaving the rest. maybe moving around with numbers
    //"d": "r2ui.openpage(0)",
    // "a": "r2ui.openpage(1)",
    //"h": "r2ui.openpage(2)",
    //"g": "r2ui.openpage(3)",
    //"c": "r2ui.openpage(5)",
    // "s": "r2ui.openpage(8)",
    // Moved to disassembled panel
    //";": "r2.cmd('CC '+prompt('comment'));r2ui.seek('$$',false);",
    //"C-3": "this.setIndex(2)",
  }
}
