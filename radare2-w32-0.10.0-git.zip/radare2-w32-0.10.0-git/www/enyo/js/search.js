enyo.kind ({
  name: "Search",
  kind: "Scroller",
  style: "background-color:#303030",
  components: [
    {tag: "center", components: [
      {tag: "h1", style: "color:#f0f0f0", content: "TODO: Search"}
    ]}
  ]
});
