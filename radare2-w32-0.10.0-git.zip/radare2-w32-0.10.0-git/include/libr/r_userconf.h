#ifndef R2_CONFIGURE_H
#define R2_CONFIGURE_H

#include "r_version.h"

#ifdef LIL_ENDIAN
#undef LIL_ENDIAN
#endif
#define LIL_ENDIAN 1
#define CPU_ENDIAN 0

#define DEBUGGER 1

#if __WIN32__ || __CYGWIN__ || MINGW32
#define R2_PREFIX "."
#define R2_LIBDIR "./lib"
#define R2_INCDIR "./include/libr"
#define R2_DATDIR "./share"
#else
#define R2_PREFIX "/usr/local"
#define R2_LIBDIR "/usr/local/lib"
#define R2_INCDIR "/usr/local/include/libr"
#define R2_DATDIR "/usr/local/share"
#endif

#define R2_VERSION "0.10.0-git"
#define HAVE_LIB_MAGIC 1
#define USE_LIB_MAGIC 0
#ifndef HAVE_LIB_SSL
#define HAVE_LIB_SSL 0
#endif
#ifndef HAVE_LIB_EWF
#define HAVE_LIB_EWF @HAVE_LIB_EWF@
#endif

#define HAVE_FORK 1

#define WITH_GPL 1

#define R2_WWWROOT "/usr/local/share/radare2/0.10.0-git/www"

#endif
