IDA
======

You can find conversion scripts to work between radare2 and IDA files (IDC, IDB...) in the repo:

* https://github.com/radare/radare2ida

